<?php
/**
 * The sidebar containing the widget area for the leftside of the page.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package gwangi
 */

do_action( 'gwangi_sidebar_left' );
